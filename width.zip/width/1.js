var cpro_id = "u1676757";
var otherJS = 'http://cpro.baidustatic.com/cpro/ui/f.js';//js的地址，请自定义
document.write('<scr' + 'ipt type="text/javascript" src="'+otherJS+'"></scr' + 'ipt>');